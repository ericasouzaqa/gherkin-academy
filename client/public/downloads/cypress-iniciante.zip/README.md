# Projeto Cypress: primeiros passos

Este projeto é um ponto de partida para praticar visita, seleção, preenchimento e asserção. Execute `npm install` e depois `npx cypress open`.
