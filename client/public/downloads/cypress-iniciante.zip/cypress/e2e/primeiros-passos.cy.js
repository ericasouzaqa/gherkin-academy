describe("Primeiros passos", () => {
  it("visita uma página e verifica o título", () => {
    cy.visit("https://example.cypress.io")
    cy.contains("Kitchen Sink").should("be.visible")
  })
})
