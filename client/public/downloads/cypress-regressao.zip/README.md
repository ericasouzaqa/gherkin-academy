# Projeto Cypress: regressão

Exemplo de organização com spec, fixture e interceptação. Execute `npm install` e depois `npx cypress run`.
