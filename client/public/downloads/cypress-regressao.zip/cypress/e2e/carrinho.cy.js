describe("Carrinho", () => {
  it("carrega produtos de uma resposta controlada", () => {
    cy.intercept("GET", "/api/products", { fixture: "products.json" }).as("products")
    cy.request("https://example.cypress.io/api/products")
      .its("body.0.name")
      .should("equal", "Caderno")
  })
})
